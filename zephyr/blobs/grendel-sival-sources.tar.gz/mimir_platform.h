/* Mimir Platform-Specific Header
 * Copyright (c) 2025 Tenstorrent
 * SPDX-License-Identifier: Apache-2.0
 *
 * This header contains Mimir-specific register definitions and configurations.
 * It is automatically included by platform.h when building for Mimir platforms.
 *
 * All Mimir platform code should use this header to access registers.
 * This ensures the correct platform-specific register definitions are used.
 */

#ifndef MIMIR_PLATFORM_H
#define MIMIR_PLATFORM_H

/* Include Mimir SoC register definitions
 * This is the authoritative source for Mimir register addresses and layouts.
 * Generated from: mimir_soc/meta/registers/c/mimir_soc_reg.h
 */
#include "mimir_soc_reg.h"

/* To include chippy naming convention for registers, include the following
 * header */
// #include "chippy_mimir_soc_reg.h"

/* Optional: SMC view alternative registers
 * Uncomment if your application needs SMC-specific view of registers
 * WARNING: Including both mimir_soc_reg.h and mimir_soc_smc_view_alt_reg.h
 * causes type conflicts. Only include one at a time, or use conditional
 * compilation.
 */
// #include "mimir_soc_smc_view_alt_reg.h"

/* Mimir-specific platform constants */
#define PLATFORM_NAME "Mimir"
#define PLATFORM_ID 0x01
#define MIMIR_SOC_VERSION_MAJOR 1
#define MIMIR_SOC_VERSION_MINOR 0

/* Platform identification macros (set by build system) */
#define PLATFORM_CHIP_MIMIR 1
#define PLATFORM_CHIP "mimir"

/* Component identification (set by build system via PLATFORM_MIMIR_SMC or
 * PLATFORM_MIMIR_CCE) */
#ifdef PLATFORM_MIMIR_SMC
#define PLATFORM_COMPONENT_SMC 1
#define PLATFORM_COMPONENT "smc"
#endif

#ifdef PLATFORM_MIMIR_CCE
#define PLATFORM_COMPONENT_CCE 1
#define PLATFORM_COMPONENT "cce"
#endif

/* Helper macros for platform-specific code */
#define IS_MIMIR_PLATFORM() 1
#define IS_KER_PLATFORM() 0

#ifdef PLATFORM_MIMIR_SMC
#define IS_SMC_COMPONENT() 1
#define IS_CCE_COMPONENT() 0
#else
#define IS_SMC_COMPONENT() 0
#define IS_CCE_COMPONENT() 1
#endif

#endif /* MIMIR_PLATFORM_H */
